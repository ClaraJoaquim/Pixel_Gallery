export class UsuarioForm {
    nome : string;
    telefone: string;
    login: string;
    senha: string;
    }
    