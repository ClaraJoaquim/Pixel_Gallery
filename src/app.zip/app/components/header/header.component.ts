import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UsuarioDTO } from '../usuario.dto';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  perfil: boolean = false;
  id: number;

  constructor(private router: Router) {}

  ngOnInit() {
    // Escuta mudanças na rota
    this.router.events.subscribe(() => {
      this.checkIfProfileRoute();
    });
  }

  checkIfProfileRoute() {
    (usuarioDTO: UsuarioDTO) => {
      this.id = usuarioDTO.id;
    };

    const baseApiUrl = '/perfil/';
    const currentRoute = this.router.url;

    this.perfil = currentRoute.startsWith(baseApiUrl);
  }
}
