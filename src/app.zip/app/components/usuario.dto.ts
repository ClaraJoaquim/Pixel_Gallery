export class UsuarioDTO {
    id: number;
    nome: string;
    telefone: string;
    login: string;
    senha: string;
}
  