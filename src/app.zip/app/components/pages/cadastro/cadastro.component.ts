import { Component, OnInit, EventEmitter, Input, Output } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Usuario } from 'src/app/Usuario';
import { Router } from '@angular/router';
import { UsuarioService } from 'src/app/services/usuario.service';
import { UsuarioForm } from '../../usuario.form';
import { ToastyService } from 'ng2-toasty';

@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.component.html',
  styleUrls: ['./cadastro.component.css']
})
export class CadastroComponent implements OnInit {
  @Output() onSubmit = new EventEmitter<Usuario>();
  @Input() usuarioData: Usuario | null = null;
  apertou:boolean = false;

  cadastroForm!: FormGroup;

  constructor(
    private usuarioService:UsuarioService,
    private router: Router,
    private toastyService: ToastyService,
  ) { }

  ngOnInit(): void {
    this.cadastroForm = new FormGroup ({
      nome: new FormControl(this.usuarioData ? this.usuarioData.nome: '', [Validators.required]),
      email: new FormControl(this.usuarioData ? this.usuarioData.login: '', [Validators.required]),
      senha: new FormControl(this.usuarioData ? this.usuarioData.senha: '', [Validators.required]),
      telefone: new FormControl(this.usuarioData ? this.usuarioData.telefone: '', [Validators.required]),
    })
  }

  cadastrar() {

    if(this.cadastroForm.invalid) {
      this.apertou = true;
      this.toastyService.error("Cadastro não realizado. Verifique os dados");
      return
    }

    const usuarioForm: Usuario = new UsuarioForm();
    usuarioForm.nome = this.cadastroForm.get("nome").value;
    usuarioForm.telefone = this.cadastroForm.get("telefone").value;
    usuarioForm.login = this.cadastroForm.get("email").value;
    usuarioForm.senha = this.cadastroForm.get("senha").value;

    this.usuarioService.createUsuario(usuarioForm).subscribe(() => {
        this.toastyService.success("Cadastro Realizado com Sucesso");
        setTimeout (() => {
          this.router.navigate([`/login`]).then(() => {
            window.location.reload();
          });
        }, 1500);
    });
  }

  get nome() {
    return this.cadastroForm.get('nome');
  }

  get telefone() {
    return this.cadastroForm.get('telefone');
  }

  get email() {
    return this.cadastroForm.get('email');
  }

  get senha() {
    return this.cadastroForm.get('senha');
  }
}