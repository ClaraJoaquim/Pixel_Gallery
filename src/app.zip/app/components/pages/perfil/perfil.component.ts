import { Component, OnInit, Input } from '@angular/core';
import { UsuarioService } from 'src/app/services/usuario.service';
import { UsuarioDTO } from '../../usuario.dto';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastyService } from 'ng2-toasty';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-perfil',
  templateUrl: './perfil.component.html',
  styleUrls: ['./perfil.component.css']
})
export class PerfilComponent implements OnInit {
  apertou: boolean = false;
  apertou2: boolean = true;
  dados: UsuarioDTO;
  cadastroForm: FormGroup;

  constructor(
    private usuarioService: UsuarioService,
    private route: ActivatedRoute,
    private router: Router,
    private toastyService: ToastyService,
    private formBuilder: FormBuilder
  ) { }


  ngOnInit(): void {
    const usuario = localStorage.getItem('usuario');
    if (usuario) {
      this.dados = JSON.parse(usuario);
      this.cadastroForm = this.formBuilder.group({
        id: this.dados.id,
        nome: [this.dados.nome],
        telefone: [this.dados.telefone],
        email: [this.dados.login],
        senha: [this.dados.senha],
      });
    }
  }

  mostrarDados() {
    this.apertou = true;
    this.apertou2 = false;
  }

  async alterarDados () {
    const id = this.dados.id;

    const dadosAtualizados = {
      id: id,
      nome: this.cadastroForm.get('nome').value,
      telefone: this.cadastroForm.get('telefone').value,
      login: this.cadastroForm.get('email').value,
      senha: this.cadastroForm.get('senha').value
    };

    localStorage.setItem('usuario', JSON.stringify(dadosAtualizados));
  
    this.usuarioService.alterarUsuario(id, dadosAtualizados).subscribe();
    this.toastyService.success("Dados alterados com sucesso!")
    setTimeout(() => {
        window.location.reload();
    }, 1500);
  }

  excluirUsuario(id: number) {
    this.usuarioService.excluirUsuario(id).subscribe(
    );
    this.toastyService.success("Usuário excluído com sucesso!")
    setTimeout(() => {
      this.router.navigate(['/']).then(() => {
        window.location.reload();
      });
    }, 1500);
  }
}