export interface Usuario {
    nome: string;
    login: string;
    senha: string;
    telefone: string;
}
